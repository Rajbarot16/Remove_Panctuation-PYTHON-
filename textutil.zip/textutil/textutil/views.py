from django.http import HttpResponse
from django.shortcuts import render
from collections import Counter


def index(request):
    
    return render(request,'index.html')
    #return HttpResponse("Home")



def analyze(request):
    
#Chackbox Values

    djtext = request.GET.get('text','default')
    remove  = request.GET.get('remove','default')
    uppers = request.GET.get('uppers','off')
    newline = request.GET.get('newline','off')
    charcount = request.GET.get('charcount','off')
    

    if remove == "on":
        panctuation= '''!()-[]-{};:'"\,<>/?@#$%^&*_~`'''
        analyzed = ""
        for char in djtext:
            if char not in panctuation:
                analyzed = analyzed + char
        params = {'purpose':'Remove panctuation','Analysis_text':analyzed}
        return render(request,'analyze.html',params)

# UPPERCASE  TEXT           

    elif (uppers == "on"):
        analyzed =""
        for char in djtext:
            analyzed = analyzed + char.upper()
            params = {'purpose':'change to UpperCase','Analysis_text':analyzed}
        return render(request,'analyze.html',params)

    elif(newline == "on"):
        analyze = ""
        for char in djtext:
            if char !="\n":
                analyze = analyze + char
        params = {'purpose':'Remove New Line','Analysis_text':analyze}
        return render(request,'analyze.html',params)

    elif (charcount == "on"):
        s="sss"
        analyzed =""
        count = s.count(analyzed)
        params = {'purpose':'Remove New Line','Analysis_text':analyzed}
    return render(request,'analyze.html',params)

